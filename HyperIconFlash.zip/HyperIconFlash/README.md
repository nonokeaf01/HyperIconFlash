# HyperIconFlash

On-device Android app that automates converting installed 3rd-party Play Store icon packs into HyperOS theme `.mrc` icon archives using Shizuku (no PC or root required).

## Build APK with GitHub Actions

1. Extract this archive and push the contents to a GitHub repository (branch `main`).
2. Open the **Actions** tab and run **Build APK** (or let the push trigger it).
3. Download the `HyperIconFlash-apk` artifact and install `app-debug.apk` on your HyperOS device.

## Usage on HyperOS

1. Install and start **Shizuku** (via Wireless Debugging).
2. Install any 3rd-party icon pack from the Play Store.
3. Download a free **dummy icon theme** from the Xiaomi Themes store (this supplies `transform_config.xml` and the target `.mrc` file).
4. Open **Hyper Icon Flash**, grant Shizuku permission, select your icon pack, and tap **Build & flash into dummy theme**.
5. Open **Themes → Icons** and apply the dummy theme's icons.
6. Use **Restore backup** at any time to revert the dummy theme's `.mrc` file.
